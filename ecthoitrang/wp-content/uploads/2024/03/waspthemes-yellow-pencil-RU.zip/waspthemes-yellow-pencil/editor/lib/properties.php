<?php

// Don't run this file directly.
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* ---------------------------------------------------- */
/* All CSS Options and settings
/* ---------------------------------------------------- */
echo "<form autocomplete='off' spellcheck='false' autocorrect='off' autocapitalize='off'><ul class='ed-pnl-list list-active'>

		<li class='text-option'>
			<h3>Text</h3>
			<div class='wyp-t-cont'>

				".wyp_get_select_markup(
					'font-family',
					'Font Family',
					"google-fonts.json",
					"",
					'Set a font family.'
				)."

				<div class='option-group-class option-group-vn-p'>
				".wyp_get_color_markup(
					'color',
					'Color',
					'Set the text color.'
				)."

				".wyp_get_select_markup(
					'font-weight',
					'Weight',
					array(
						'300' => 'Light'.' 300',
						'400' => 'Regular'.' 400',
						'500' => 'Medium'.' 500',
						'600' => 'Bold'.' 600',
						'700' => 'Extra'.' 700'
					),
					"",
					'Устанавливает, насколько толстые или тонкие символы в тексте должны отображаться.'
				)."
				</div>

				".wyp_get_slider_markup(
					'font-size',
					'Размер шрифта',
					"",
					1,        // steps
					'8,100',   // px value
					'0,100',  // percentage value
					'1,6',     // Em value
					'Устанавливает размер шрифта.'
				)."

				".wyp_get_slider_markup(
					'line-height',
					'Высота линии',
					"",
					0.1,        // steps
					'0,100',   // px value
					'0,100',  // percentage value
					'1,6',     // Em value,
					'Set the leading.'
				)."

				<div class='option-group-class option-group-less'>
				".wyp_get_radio_markup(
					'font-style',
					'Style',
					array(
						'normal' => 'normal',
						'italic' => 'italic'
					),
					"",
					'Определяет стиль шрифта для текста.'
				)."

				".wyp_get_radio_markup(
					'text-transform',
					'Трансформировать',
					array(
						'none' => 'no',
						'capitalize' => 'Aa',
						'uppercase' => 'AA',
						'lowercase' => 'aa',
					),
					"",
					'Контролирует использование заглавных букв в тексте.'
				)."
				</div>

				<div class='option-group-class option-group-less'>
				".wyp_get_radio_markup(
					'text-decoration',
					'Украшение',
					array(
						'none' => 'A',
						'overline' => 'A',
						'line-through' => 'A',
						'underline' => 'A'
					),
					"",
					'Определяет украшение, добавляемое к тексту.'
				)."

				".wyp_get_radio_markup(
					'text-align',
					'Выровнять',
					array(
						'left' => '<span class="yicon icon-editor-alignleft"></span>',
						'center' => '<span class="yicon icon-editor-aligncenter"></span>',
						'right' => '<span class="yicon icon-editor-alignright"></span>',
						'justify' => '<span class="yicon icon-editor-justify"></span>'
					),
					"",
					'Определяет горизонтальное выравнивание текста в элементе.'
				)."
				</div>

				<div class='option-group-class option-group-less'>
				".wyp_get_select_markup(
					'text-shadow',
					'Тень текста',
					array(
						'none' => 'none',
						'rgba(0, 0, 0, 0.3) 0px 1px 1px' => 'Basic',
						'rgb(255, 255, 255) 1px 1px 0px, rgb(170, 170, 170) 2px 2px 0px' => 'Multiple',
						'rgb(255, 0, 0) -1px 0px 0px, rgb(0, 255, 255) 1px 0px 0px' => 'Anaglyph',
						'rgb(255, 255, 255) 0px 1px 1px, rgb(0, 0, 0) 0px -1px 1px' => 'Emboss',
						'rgb(255, 255, 255) 0px 0px 2px, rgb(255, 255, 255) 0px 0px 4px, rgb(255, 255, 255) 0px 0px 6px, rgb(255, 119, 255) 0px 0px 8px, rgb(255, 0, 255) 0px 0px 12px, rgb(255, 0, 255) 0px 0px 16px, rgb(255, 0, 255) 0px 0px 20px, rgb(255, 0, 255) 0px 0px 24px' => 'Neon',
						'rgb(0, 0, 0) 0px 1px 1px, rgb(0, 0, 0) 0px -1px 1px, rgb(0, 0, 0) 1px 0px 1px, rgb(0, 0, 0) -1px 0px 1px' => 'Outline'
					),
					"",
					'Добавляет тень к тексту.'
				)."

				".wyp_get_select_markup(
					'white-space',
					'Разрыв',
					array(
						'normal' => 'Normal',
						'nowrap' => 'No Wrap',
						'pre' => 'Pre',
						'pre-line' => 'Pre Line',
						'pre-wrap' => 'Предварительная упаковка',
						'break-spaces' => 'Разрыв пробелов'
					),
					"",
					'Указывает, как обрабатывается пробел внутри элемента..'
				)."
				</div>

				".wyp_get_slider_markup(
					'letter-spacing',
					'Межбуквенное расстояние',
					"normal",
					0.1,        // steps
					'-5,10',   // px value
					'0,100',  // percentage value
					'-1,3',     // Em value
					'Увеличивает или уменьшает расстояние между символами в тексте.'
				)."

				".wyp_get_slider_markup(
					'word-spacing',
					'Word Spacing',
					"normal",
					0.1,        // steps
					'-5,20',   // px value
					'0,100',  // percentage value
					'-1,3',     // Em value,
					'Увеличивает или уменьшает пробел между словами.'
				)."

				<div class='option-group-class option-group-less cl-direction'>
					".wyp_get_slider_markup(
						'column-count',
						'Columns',
						'',
						1,        // steps
						'1,12',   // px value
						'1,12',  // percentage value
						'1,12',     // Em value
						'Определяет количество столбцов, на которые должен быть разделен элемент.'
					)."

					".wyp_get_radio_markup(
						'direction',
						'Direction',
						array(
							'ltr' => 'left',
							'rtl' => 'right'
						),
						"",
						'Определяет направление текста/направление письма внутри блочного элемента.'
					)."
				</div>

			</div>
		</li>";


		$backdrop_filter_status = apply_filters( 'yp_property__backdrop-filter', TRUE);

		echo "<li class='background-option'>
			<h3>Фон</h3>
			<div class='wyp-t-cont'>";

				if($backdrop_filter_status){
					echo wyp_get_radio_markup(
						'background-type',
						'Тип фона',
						array(
							'background' => 'background',
							'filter' => 'backdrop filters'
						),
						"",
						''
					);
				}

				echo "<div class='wyp-background-background-section'>
				".wyp_get_color_markup(
					'background-color',
					'Цвет',
					'Устанавливает цвет фона элемента.'
				)."

				".wyp_get_input_markup(
					'background-image',
					'Изображение',
					'Устанавливает фоновое изображение для элемента.'
				)."

				".wyp_get_radio_markup(
					'background-size',
					'Размер',
					array(
						'auto' => 'custom',
						'cover' => 'cover',
						'contain' => 'contain'
					),
					"",
					'The size of the background image.'
				)."

				<div class='option-group-class background-cgn'>
				".wyp_get_select_markup(
					'background-blend-mode',
					'Режим смешивания',
					array(
						'normal' => 'normal',
						'multiply' => 'multiply',
						'screen' => 'screen',
						'overlay' => 'overlay',
						'darken' => 'darken',
						'lighten' => 'lighten',
						'color-dodge' => 'color-dodge',
						'saturation' => 'saturation',
						'color' => 'color',
						'luminosity' => 'luminosity'
					),
					"",
					'Определяет режим наложения цвета фона и изображения..'
				)."

				".wyp_get_radio_markup(
					'background-attachment',
					'Фиксировано',
					array(
						'fixed' => 'fixed',
						'scroll' => 'scroll',
					),
					"",
					'Устанавливает, будет ли фоновое изображение фиксированным или прокручивается вместе с остальной частью страницы..'
				)."

				</div>

				".wyp_get_slider_markup(
					'background-position-x',
					'Горизонтальное положение',
					"",
					1,        // steps
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value,
					'Устанавливает начальную позицию фонового изображения по горизонтали..'
				)."

				".wyp_get_slider_markup(
					'background-position-y',
					'Vertical Position',
					"",
					1,        // steps
					'0,200',   // px value
					'0,100',  // percentage value
					'0,26',     // Em value,
					'Устанавливает начальную позицию фонового изображения по вертикали..'
				)."

				".wyp_get_radio_markup(
					'background-repeat',
					'Плитка',
					array(
						'repeat' => '<svg focusable="false" width="16" height="16" viewBox="0 0 16 16"><path fill="currentColor" d="M1 1h4v4H1zm5 0h4v4H6zm5 0h4v4h-4zM1 6h4v4H1zm5 0h4v4H6zm5 0h4v4h-4zM1 11h4v4H1zm5 0h4v4H6zm5 0h4v4h-4z"></path></svg>',
						'repeat-x' => '<svg focusable="false" width="16" height="16" viewBox="0 0 16 16"><path fill="currentColor" d="M1 6h4v4H1zm5 0h4v4H6zm5 0h4v4h-4z"></path></svg>',
						'repeat-y' => '<svg focusable="false" width="16" height="16" viewBox="0 0 16 16"><path fill="currentColor" d="M6 1h4v4H6zm0 5h4v4H6zm0 5h4v4H6z"></path></svg>',
						'no-repeat' => '<span class="yicon icon-no-alt"></span>'
					),
					"",
					'Устанавливает, будет ли повторяться фоновое изображение.'
				)."

				".wyp_get_radio_markup(
					'background-clip',
					'Clip',
					array(
						'text' => 'text',
						'border-box' => 'border',
						'padding-box' => 'padding'
					),
					"",
					"Определяет, насколько далеко должен простираться фон внутри элемента.."
				)."
				</div>";

				if($backdrop_filter_status){
				echo "<div class='wyp-background-filter-section'>

					".wyp_get_slider_markup(
						'blur-backdrop-filter',
						'Blur',
						'',
						0.01,        // steps
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'grayscale-backdrop-filter',
						'Grayscale',
						'',
						0.01,        // steps
						'0,1',   // px value
						'0,1',  // percentage value
						'0,1',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'invert-backdrop-filter',
						'Invert',
						'',
						0.01,        // steps
						'0,1',   // px value
						'0,1',  // percentage value
						'0,1',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'sepia-backdrop-filter',
						'Sepia',
						'',
						0.01,        // steps
						'0,1',   // px value
						'0,1',  // percentage value
						'0,1',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'brightness-backdrop-filter',
						'Яркость',
						'',
						0.01,        // steps
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'contrast-backdrop-filter',
						'Контраст',
						'',
						0.01,        // steps
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'hue-rotate-backdrop-filter',
						'Оттенок Поворот',
						'',
						1,        // steps
						'0,360',   // px value
						'0,360',  // percentage value
						'0,360',     // Em value
						""
					)."

					".wyp_get_slider_markup(
						'saturate-backdrop-filter',
						'Saturate',
						'',
						0.01,        // steps
						'0,10',   // px value
						'0,10',  // percentage value
						'0,10',     // Em value
						""
					)."

				</div>";

				}

			echo "</div>
		</li>

		<li class='spacing-option'>
			<h3>Промежутки</h3>
			<div class='wyp-t-cont'>

				".wyp_get_radio_markup(
					'spacing-type',
					'Тип интервала',
					array(
						'padding' => 'padding',
						'margin' => 'margin'
					),
					"",
					''
				)."

				<div class='wyp-spacing-padding-section'>
					".wyp_get_slider_markup(
						'padding-left',
						'Внутр-отступ слева',
						'',
						1,        // steps
						'0,200',   // px value
						'0,100',  // percentage value
						'0,26',     // Em value
						'Устанавливает левый отступ (пробел) элемента.'
					)."

					".wyp_get_slider_markup(
						'padding-right',
						'Внутр-отступ справа',
						'',
						1,        // steps
						'0,200',   // px value
						'0,100',  // percentage value
						'0,26',     // Em value
						'Устанавливает правый отступ (пробел) элемента.'
					)."

					".wyp_get_slider_markup(
						'padding-top',
						'Внутр-отступ сверху',
						'',
						1,        // steps
						'0,200',   // px value
						'0,100',  // percentage value
						'0,26',     // Em value
						'Устанавливает верхний отступ (пробел) элемента.'
					)."

					".wyp_get_slider_markup(
						'padding-bottom',
						'Внутр-отступ снизу',
						'',
						1,        // steps
						'0,200',   // px value
						'0,100',  // percentage value
						'0,26',     // Em value
						'Устанавливает нижний отступ (пробел) элемента.'
					)."
				</div>

				<div class='wyp-spacing-margin-section'>
					".wyp_get_slider_markup(
						'margin-left',
						'Поле слева',
						"auto",
						1,        // steps
						'-50,200',   // px value
						'-100,100',  // percentage value
						'-6,26',     // Em value,
						'Устанавливает левое поле элемента.'
					)."

					".wyp_get_slider_markup(
						'margin-right',
						'Поле справа',
						"auto",
						1,        // steps
						'-50,200',   // px value
						'-100,100',  // percentage value
						'-6,26',     // Em value
						'Устанавливает правое поле элемента.'
					)."

					".wyp_get_slider_markup(
						'margin-top',
						'Внеш-отступ Верху',
						'',
						1,        // steps
						'-50,200',   // px value
						'-100,100',  // percentage value
						'-6,26',     // Em value
						'Устанавливает верхнее поле элемента.'
					)."

					".wyp_get_slider_markup(
						'margin-bottom',
						'Поле внизу',
						'',
						1,        // steps
						'-50,200',   // px value
						'-100,100',  // percentage value
						'-6,26',     // Em value
						'Устанавливает нижнее поле элемента.'
					)."
				</div>

			</div>
		</li>

		<li class='border-option'>
			<h3>Borders</h3>
			<div class='wyp-t-cont'>

				".wyp_get_radio_markup(
					'border-type',
					'Тип границы',
					array(
						'all' => 'all',
						'top' => 'top',
						'right' => 'right',
						'bottom' => 'bottom',
						'left' => 'left'
					),
					"",
					''
				)."

				<div class='wyp-border-all-section'>

					<div class='option-group-class'>
					".wyp_get_color_markup(
						'border-color',
						'Цвет',
						'Устанавливает цвет четырех границ элемента.'
					)."

					".wyp_get_radio_markup(
						'border-style',
						'Style',
						array(
							'none' => '<span class="yicon icon-no-alt"></span>',
							'solid' => '',
							'dotted' => '',
							'dashed' => ''
						),
						"",
						'Устанавливает стиль четырех границ элемента.'
					)."
					</div>

					".wyp_get_slider_markup(
						'border-width',
						'Ширина',
						'',
						1,        // steps
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Устанавливает ширину четырех границ элемента.'
					)."

				</div>

				<div class='wyp-border-top-section'>

					<div class='option-group-class'>
					".wyp_get_color_markup(
						'border-top-color',
						'Цвет',
						'Устанавливает цвет верхней границы элемента.'
					)."

					".wyp_get_radio_markup(
						'border-top-style',
						'Стиль',
						array(
							'none' => '<span class="yicon icon-no-alt"></span>',
							'solid' => '',
							'dotted' => '',
							'dashed' => ''
						),
						"",
						'Устанавливает стиль верхней границы элемента.'
					)."
					</div>

					".wyp_get_slider_markup(
						'border-top-width',
						'Ширина',
						'',
						1,        // steps
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Устанавливает ширину верхней границы элемента.'
					)."

				</div>

				<div class='wyp-border-right-section'>

					<div class='option-group-class'>
					".wyp_get_color_markup(
						'border-right-color',
						'Цвет',
						'Устанавливает цвет правой границы элемента.'
					)."

					".wyp_get_radio_markup(
						'border-right-style',
						'Стиль',
						array(
							'none' => '<span class="yicon icon-no-alt"></span>',
							'solid' => '',
							'dotted' => '',
							'dashed' => ''
						),
						"",
						'Устанавливает стиль правой границы элемента.'
					)."
					</div>

					".wyp_get_slider_markup(
						'border-right-width',
						'Ширина',
						'',
						1,        // steps
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Устанавливает ширину правой границы элемента.'
					)."

				</div>


				<div class='wyp-border-bottom-section'>

					<div class='option-group-class'>
					".wyp_get_color_markup(
						'border-bottom-color',
						'Цвет',
						'Устанавливает цвет нижней границы элемента.'
					)."

					".wyp_get_radio_markup(
						'border-bottom-style',
						'Style',
						array(
							'none' => '<span class="yicon icon-no-alt"></span>',
							'solid' => '',
							'dotted' => '',
							'dashed' => ''
						),
						"",
						'Устанавливает стиль нижней границы элемента.'
					)."
					</div>

					".wyp_get_slider_markup(
						'border-bottom-width',
						'Ширина',
						'',
						1,        // steps
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Устанавливает ширину нижней границы элемента.'
					)."

				</div>


				<div class='wyp-border-left-section'>

					<div class='option-group-class'>
					".wyp_get_color_markup(
						'border-left-color',
						'Цвет',
						'Устанавливает цвет левой границы элемента.'
					)."

					".wyp_get_radio_markup(
						'border-left-style',
						'Стиль',
						array(
							'none' => '<span class="yicon icon-no-alt"></span>',
							'solid' => '',
							'dotted' => '',
							'dashed' => ''
						),
						"",
						'Устанавливает стиль левой границы элемента.'
					)."
					</div>

					".wyp_get_slider_markup(
						'border-left-width',
						'Width',
						'',
						1,        // steps
						'0,20',   // px value
						'0,100',  // percentage value
						'0,3',     // Em value
						'Устанавливает ширину левой границы элемента.'
					)."

				</div>

			</div>
		</li>

		<li class='border-radius-option'>
			<h3>Радиус границы</h3>
			<div class='wyp-t-cont'>

				".wyp_get_slider_markup(
					'border-top-left-radius',
					'Радиус вверху слева',
					'',
					"1",        // steps
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Определяет радиус верхнего левого угла.'
				)."

				".wyp_get_slider_markup(
					'border-top-right-radius',
					'Радиус вверху справа',
					'',
					"1",        // steps
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Определяет радиус правого верхнего угла.'
				)."

				".wyp_get_slider_markup(
					'border-bottom-left-radius',
					'Радиус внизу слева',
					'',
					"1",        // steps
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Определяет радиус нижнего левого угла.'
				)."

				".wyp_get_slider_markup(
					'border-bottom-right-radius',
					'Radius Bottom Right',
					'',
					"1",        // steps
					'0,50',   // px value
					'0,50',  // percentage value
					'0,6',     // Em value
					'Определяет радиус нижнего правого угла.'
				)."

			</div>
		</li>

		<li class='position-option'>
			<h3>Позиционирование</h3>
			<div class='wyp-t-cont'>

				".wyp_get_slider_markup(
					'z-index',
					'Z Index',
					"auto",
					1,        // steps
					'-10,1000',   // px value
					'-10,1000',  // percentage value
					'-10,1000',     // Em value
					'Определяет порядок элемента в стеке. Индекс Z работает только с позиционированными элементами (абсолютными, относительными или фиксированными).).'
				)."

				".wyp_get_radio_markup(
					'position',
					'Position',
					array(
						'static' => 'static',
						'relative' => 'relative',
						'absolute' => 'absolute',
						'fixed' => 'fixed',
						'sticky' => 'sticky'
					),
					"",
					'Определяет тип метода позиционирования, используемого для элемента.'

				)."

				".wyp_get_slider_markup(
					'top',
					'Верх',
					"auto",
					1,        // steps
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'Для абсолютно: позиционированных элементов свойство top устанавливает верхний край элемента на единицу выше/ниже верхнего края содержащего его элемента..<br><br>Для относительно: позиционированных элементов свойство top устанавливает верхний край элемента на единицу выше/ниже его нормального положения..'
				)."

				".wyp_get_slider_markup(
					'left',
					'Слева',
					"auto",
					1,        // steps
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'Для абсолютно: позиционированных элементов свойство left устанавливает левый край элемента на единицу слева/справа от левого края содержащего его элемента..<br><br>Для относительно: позиционированных элементов свойство left устанавливает левый край элемента на единицу слева/справа от его нормального положения..'
				)."

				".wyp_get_slider_markup(
					'bottom',
					'Низ',
					"auto",
					1,        // steps
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'Для абсолютно: позиционированных элементов свойство bottom устанавливает нижний край элемента на единицу выше/ниже нижнего края содержащего его элемента..<br><br>Для относительно: позиционированных элементов свойство bottom устанавливает нижний край элемента на единицу выше/ниже его нормального положения..'
				)."

				".wyp_get_slider_markup(
					'right',
					'Справа',
					"auto",
					1,        // steps
					'-200,400',   // px value
					'0,100',  // percentage value
					'-12,12',     // Em value
					'Для абсолютно: позиционированных элементов свойство right устанавливает правый край элемента на единицу слева/справа от правого края содержащего его элемента..<br><br>Для относительно: позиционированных элементов свойство right устанавливает правый край элемента на единицу слева/справа от его нормального положения..'
				)."

			</div>
		</li>

		<li class='size-option'>
			<h3>Меры</h3>
			<div class='wyp-t-cont'>

				".wyp_get_slider_markup(
					'width',
					'Ширина',
					"auto",
					1,        // steps
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Sets the width of an element.'
				)."

				".wyp_get_slider_markup(
					'height',
					'Высота',
					"auto",
					1,        // steps
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Sets the height of an element'
				)."

				".wyp_get_radio_markup(
					'overflow',
					'Переполнение',
					array(
						'visible' => 'visible',
						'hidden' => 'hidden',
						'scroll' => 'scroll',
						'auto' => 'auto'
					),
					"",
					'Определяет, что должно произойти, если содержимое переполняет поле элемента.'
				)."

				".wyp_get_slider_markup(
					'min-width',
					'Минимальная ширина',
					"initial",
					1,        // steps
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Set the minimum width of an element.'
				)."

				".wyp_get_slider_markup(
					'max-width',
					'Максимальная ширина',
					"none",
					1,        // steps
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Установить максимальную ширину элемента.'
				)."

				".wyp_get_slider_markup(
					'min-height',
					'Min Height',
					"initial",
					1,        // steps
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',    // Em value
					'Установить минимальную высоту элемента.'
				)."

				".wyp_get_slider_markup(
					'max-height',
					'Max Height',
					"none",
					1,        // steps
					'0,500',   // px value
					'0,100',  // percentage value
					'0,52',     // Em value
					'Установить максимальную высоту элемента.'
				)."


			</div>
		</li>

		<li class='lists-option'>
			<h3>Списки</h3>
			<div class='wyp-t-cont'>

				".wyp_get_select_markup(
					'list-style-type',
					'Тип списка'
					,array(
						'none' => 'none',
						'disc' => 'disc',
						'circle' => 'circle',
						'decimal' => 'decimal',
						'lower-alpha' => 'lower alpha',
						'upper-alpha' => 'upper alpha',
						'upper-roman' => 'upper roman'
					),
					"",
					'Задает тип маркера элемента списка в списке.'
				)."

				".wyp_get_input_markup(
					'list-style-image',
					'Список изображений',
					'Заменяет маркер элемента списка изображением.'
				)."

				".wyp_get_radio_markup(
					'list-style-position',
					'Позиция в списке',
					array(
						'inside' => 'inside',
						'outside' => 'outside'
					),
					"",
					'Указывает, должны ли маркеры элементов списка появляться внутри или вне потока содержимого.'
				)."

			</div>
		</li>";

		// Transform CSS Filter
		$transform_status = apply_filters( 'yp_property__transform', TRUE);

		// Transform is valid
		if($transform_status){

			echo "<li class='transform-option'>
				<h3>Трансформ</h3>
				<div class='wyp-t-cont'>

					".wyp_get_radio_markup(
						'transform-type',
						'Тип преобразования',
						array(
							'move' => 'move',
							'rotate' => 'rotate',
							'skew' => 'skew',
							'extra' => 'extra'
						),
						"",
						''
					)."


					<div class='wyp-transform-move-section'>

						".wyp_get_slider_markup(
							'translate-x-transform',
							'Переместить по горизонтали',
							'',
							1,        // steps
							'-256,256',   // px value
							'-256,256',  // percentage value
							'-256,256',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'translate-y-transform',
							'Переместить по вертикали',
							'',
							1,        // steps
							'-256,256',   // px value
							'-256,256',  // percentage value
							'-256,256',     // Em value
							""
						)."

					</div>

					<div class='wyp-transform-rotate-section'>

						".wyp_get_slider_markup(
							'rotatex-transform',
							'Rotate X',
							'',
							1,        // steps
							'-180,180',   // px value
							'-180,180',  // percentage value
							'-180,180',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'rotatey-transform',
							'Rotate Y',
							'',
							1,        // steps
							'-180,180',   // px value
							'-180,180',  // percentage value
							'-180,180',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'rotatez-transform',
							'Rotate Z',
							'',
							1,        // steps
							'-180,180',   // px value
							'-180,180',  // percentage value
							'-180,180',     // Em value
							""
						)."

					</div>

					<div class='wyp-transform-skew-section'>

						".wyp_get_slider_markup(
							'skew-x-transform',
							'Skew X',
							'',
							1,        // steps
							'-180,180',   // px value
							'-180,180',  // percentage value
							'-180,180',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'skew-y-transform',
							'skew Y',
							'',
							1,        // steps
							'-180,180',   // px value
							'-180,180',  // percentage value
							'-180,180',     // Em value
							""
						)."

					</div>

					<div class='wyp-transform-extra-section'>

						".wyp_get_slider_markup(
							'scale-transform',
							'Scale',
							'',
							0.01,        // steps
							'0,5',   // px value
							'0,5',  // percentage value
							'0,5',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'perspective',
							'Perspective',
							'',
							1,        // steps
							'0,1000',   // px value
							'0,100',  // percentage value
							'0,62',     // Em value
							""
						)."

					</div>

			</div></li>";

		}


		$box_shadow_status = apply_filters( 'yp_property__box-shadow', TRUE);

		if($box_shadow_status){
		echo "<li class='box-shadow-option'>
			<h3>Тень</h3>
			<div class='wyp-t-cont'>

				".wyp_get_radio_markup(
					'box-shadow-inset',
					'Позиция',
					array(
						'no' => 'outside',
						'inset' => 'inside'
					),
					false,
					'Определяет, находится ли тень внутри или снаружи.'
				)."

				".wyp_get_color_markup(
					'box-shadow-color',
					'Цвет',
					'Устанавливает цвет тени.'
				)."

				".wyp_get_slider_markup(
					'box-shadow-blur-radius',
					'Радиус размытия',
					'',
					1,        	// steps
					'0,50',   // px value
					'0,50',  // percentage value
					'0,50',     // Em value
					'Устанавливает радиус размытия тени.'
				)."

				".wyp_get_slider_markup(
					'box-shadow-spread',
					'Spread',
					'',
					1,        	// steps
					'-50,100',   // px value
					'-50,100',  // percentage value
					'-50,100',     // Em value
					'Установить размер тени.'
				)."

				".wyp_get_slider_markup(
					'box-shadow-horizontal',
					'Горизонтальная длина',
					'',
					1,        // steps
					'-50,50',   // px value
					'-50,50',  // percentage value
					'-50,50',     // Em value
					'Устанавливает горизонтальную длину тени.'
				)."

				".wyp_get_slider_markup(
					'box-shadow-vertical',
					'Вертикальная длина',
					'',
					1,        	// steps
					'-50,50',   // px value
					'-50,50',  // percentage value
					'-50,50',     // Em value
					'Устанавливает вертикальную длину тени.'
				)."

			</div>
		</li>";
		}


		// Filter CSS Filter
		$filter_status = apply_filters( 'yp_property__filter', TRUE);

		// Filter is valid
		if($filter_status){

			echo "<li class='filter-option'>
				<h3>Фильтры</h3>
				<div class='wyp-t-cont'>

					".wyp_get_radio_markup(
						'filter-type',
						'Тип фильтра',
						array(
							'color-effects' => 'effects',
							'color-adjustment' => 'adjustments'
						),
						"",
						''
					)."


					<div class='wyp-filter-color-adjustment-section'>

						".wyp_get_slider_markup(
							'brightness-filter',
							'Яркость',
							'',
							0.01,        // steps
							'0,10',   // px value
							'0,10',  // percentage value
							'0,10',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'contrast-filter',
							'Контраст',
							'',
							0.01,        // steps
							'0,10',   // px value
							'0,10',  // percentage value
							'0,10',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'hue-rotate-filter',
							'Оттенок Поворот',
							'',
							1,        // steps
							'0,360',   // px value
							'0,360',  // percentage value
							'0,360',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'saturate-filter',
							'Насыщенность',
							'',
							0.01,        // steps
							'0,10',   // px value
							'0,10',  // percentage value
							'0,10',     // Em value
							""
						)."

					</div>

					<div class='wyp-filter-color-effects-section'>

						".wyp_get_slider_markup(
							'blur-filter',
							'Размытие',
							'',
							0.01,        // steps
							'0,10',   // px value
							'0,10',  // percentage value
							'0,10',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'grayscale-filter',
							'Оттенки серого',
							'',
							0.01,        // steps
							'0,1',   // px value
							'0,1',  // percentage value
							'0,1',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'invert-filter',
							'Invert',
							'',
							0.01,        // steps
							'0,1',   // px value
							'0,1',  // percentage value
							'0,1',     // Em value
							""
						)."

						".wyp_get_slider_markup(
							'sepia-filter',
							'Sepia',
							'',
							0.01,        // steps
							'0,1',   // px value
							'0,1',  // percentage value
							'0,1',     // Em value
							""
						)."

					</div>

			</div></li>";

		}

		echo "<li class='animation-option'>
			<h3>Движение <span class='wyp-badge wyp-anim-recording'>Rec</span></h3>
			<div class='wyp-t-cont'>

				".wyp_get_radio_markup(
					'motion-type',
					'Тип движения',
					array(
						'animation' => 'animation',
						'transition' => 'transition'
					),
					"",
					''
				)."

				<div class='wyp-motion-animation-section'>";

				// Dev Animation Tools Filter
				$filter_animation_tools = apply_filters( 'yp_animation_tools', TRUE);

				// If animation Generator Open
				if($filter_animation_tools){
					echo "<a class='wyp-advanced-link wyp-just-desktop wyp-add-animation-link'>Создать анимацию</a>";
				}

				$myAnimations = array();

				// Add dynamic my animations.
				$all_options =  wp_load_alloptions();
				foreach($all_options as $name => $value){
					if(stristr($name, 'yp_anim')){
						$name = str_replace("yp_anim_", "", $name);
						$myAnimations[$name] = array(ucwords(strtolower($name)), "my animations");
					}
				}

				// Default animations
				$defaultAnimations = array(

					'none' => ['none', 'basic'],
					'pulse' => ['pulse', 'basic'],
					'push' => ['push', 'basic'],
					'bob' => ['bob', 'basic'],
					'pop' => ['pop', 'basic'],

					'bounce' => ['bounce', 'common'],
					'flash' => ['flash', 'common'],
					'rubberBand' => ['rubberBand', 'common'],
					'shake' => ['shake', 'common'],
					'swing' => ['swing', 'common'],
					'tada' => ['tada', 'common'],
					'wobble' => ['wobble', 'common'],
					'wobble-horizontal' => ['wobble-horizontal', 'common'],
					'jello' => ['jello', 'common'],
					'heartBeat' => ['heartBeat', 'common'],
					'spin' => ['spin', 'common'],

					'bounceIn' => ['bounceIn', 'bounce'],
					'bounceInDown' => ['bounceInDown', 'bounce'],
					'bounceInLeft' => ['bounceInLeft', 'bounce'],
					'bounceInRight' => ['bounceInRight', 'bounce'],
					'bounceInUp' => ['bounceInUp', 'bounce'],

					'fadeIn' => ['fadeIn', 'fade'],
					'fadeInDown' => ['fadeInDown', 'fade'],
					'fadeInDownBig' => ['fadeInDownBig', 'fade'],
					'fadeInLeft' => ['fadeInLeft', 'fade'],
					'fadeInLeftBig' => ['fadeInLeftBig', 'fade'],
					'fadeInRight' => ['fadeInRight', 'fade'],
					'fadeInRightBig' => ['fadeInRightBig', 'fade'],
					'fadeInUp' => ['fadeInUp', 'fade'],
					'fadeInUpBig' => ['fadeInUpBig', 'fade'],

					'flip' => ['flip', 'flip'],
					'flipInX' => ['flipInX', 'flip'],
					'flipInY' => ['flipInY', 'flip'],
					'flipOutX' => ['flipOutX', 'flip'],
					'flipOutY' => ['flipOutY', 'flip'],

					'rotateIn' => ['rotateIn', 'rotate'],
					'rotateInDownLeft' => ['rotateInDownLeft', 'rotate'],
					'rotateInDownRight' => ['rotateInDownRight', 'rotate'],
					'rotateInUpLeft' => ['rotateInUpLeft', 'rotate'],
					'rotateInUpRight' => ['rotateInUpRight', 'rotate'],

					'slideInUp' => ['slideInUp', 'slide'],
					'slideInDown' => ['slideInDown', 'slide'],
					'slideInLeft' => ['slideInLeft', 'slide'],
					'slideInRight' => ['slideInRight', 'slide'],

					'zoomIn' => ['zoomIn', 'zoom'],
					'zoomInDown' => ['zoomInDown', 'zoom'],
					'zoomInLeft' => ['zoomInLeft', 'zoom'],
					'zoomInRight' => ['zoomInRight', 'zoom'],
					'zoomInUp' => ['zoomInUp', 'zoom'],

					'spaceInUp' => ['spaceInUp', 'space'],
					'spaceInRight' => ['spaceInRight', 'space'],
					'spaceInDown' => ['spaceInDown', 'space'],
					'spaceInLeft' => ['spaceInLeft', 'space'],

					'hinge' => ['hinge', 'others'],
					'jackInTheBox' => ['jackInTheBox', 'others'],
					'rollIn' => ['rollIn', 'others'],
					'lightSpeedIn' => ['lightSpeedIn', 'others']

				);

				// Merge
				$animations = array_merge($myAnimations, $defaultAnimations);

				echo " ".wyp_get_select_markup(
					'animation-name',
					'Анимация',
					$animations,
					"",
					'Добавляет анимацию к элементу.'
				)."

				<div class='option-group-class'>
				".wyp_get_select_markup(
					'animation-play',
					'Триггер',
					array(
						'yp_onscreen' => 'onScreen',
						'yp_hover' => 'Hover',
						'yp_click' => 'Click',
						'yp_focus' => 'Focus'
					),
					'',
					'OnScreen: Воспроизвести анимацию, когда элемент виден на экране.<br><br>Hover: Воспроизведение анимации при наведении мыши на элемент.<br><br>Щелчок: Воспроизвести анимацию при нажатии на элемент.<br><br>Focus: Воспроизведение элемента при нажатии на текстовое поле.'
				)."

				".wyp_get_select_markup(
					'--animation-trigger-repeat',
					'Trigger Repeat',
					array(
						'1' => '1',
						'2' => '2',
						'3' => '3',
						'4' => '4',
						'5' => '5',
						'infinite' => 'infinite'
					),
					'',
					'Указывает, сколько раз должна воспроизводиться анимация..'
				)."
				</div>

				".wyp_get_slider_markup(
					'animation-duration',
					'Продолжительность',
					'',
					0.01,        // steps
					'0,3',   // px value
					'0,3',   // percentage value
					'0,3',   // Em/ms value
					'Определяет, сколько времени должна занять анимация для завершения одного цикла..',
					's,ms'
				)."

				".wyp_get_slider_markup(
					'animation-delay',
					'Задерживать',
					'',
					0.01,        // steps
					'0,3',   // px value
					'0,3',  // percentage value
					'0,3',     // Em/ms value
					'Определяет задержку для начала анимации.',
					's,ms'
				)."

				".wyp_get_select_markup(
					'animation-timing-function',
					'Ослабление',
					array(
						'ease' => 'ease',
						'linear' => 'linear',
						'ease-in' => 'ease-in',
						'ease-out' => 'ease-out',
						'ease-in-out' => 'ease-in-out'
					),
					"",
					'Определяет кривую скорости эффекта анимации.'
				)."

				".wyp_get_radio_markup(
					'animation-fill-mode',
					'Режим заполнения анимации',
					array(
						'none' => 'none',
						'forwards' => 'forwards',
						'backwards' => 'backwards',
						'both' => 'both',
					),
					"",
					'Устанавливает состояние конечной анимации, когда анимация не выполняется.'
				)."

				</div>

				<div class='wyp-motion-transition-section'>";

					// Transition CSS Filter
				    $transition_status = apply_filters( 'yp_property__transition', TRUE);

				    // Transition is valid
				    if($transition_status){

						echo wyp_get_select_markup(
							'transition-property',
							'Тип',
							'transition-properties.json',
							"",
							'Указывает имя свойства CSS, для которого предназначен эффект перехода (эффект перехода запускается при изменении указанного свойства CSS).).'
						)."

						".wyp_get_slider_markup(
							'transition-duration',
							'Продолжительность',
							'',
							0.01,        // steps
							'0,2',   // px value
							'0,2',   // percentage value
							'0,2',   // Em/ms value
							'Указывает, сколько секунд (с) или миллисекунд (мс) требуется для завершения эффекта перехода.',
							's,ms'
						)."

						".wyp_get_select_markup(
							'transition-timing-function',
							'Easing',
							array(
								'ease' => 'ease',
								'linear' => 'linear',
								'ease-in' => 'ease-in',
								'ease-out' => 'ease-out',
								'ease-in-out' => 'ease-in-out'
							),
							"",
							'Определяет кривую скорости эффекта перехода.'
						)."";

					}

				echo "</div>

			</div>
		</li>

		<li class='extra-option'>
			<h3>Extra</h3>
			<div class='wyp-t-cont'>

					".wyp_get_select_markup(
						'display',
						'Display',
						array(
							'block' => 'block',
							'flex' => 'flex',
							'grid' => 'grid',
							'inline' => 'inline',
							'inline-block' => 'inline-block',
							'inline-flex' => 'inline-flex',
							'inline-grid' => 'inline-grid',
							'table-cell' => 'table-cell',
							'none' => 'none',
						),
						"",
						'Определяет тип поля, используемого для элемента.'
					)."

					<div class='flex-container-section'>
					".wyp_get_radio_markup(
						'flex-direction',
						'Направление',
						array(
							'row' => 'horizontal',
							'column' => 'vertical',
						),
						'',
						'Определяет направление гибких элементов.'
					)."

					<div class='option-group-class'>
					".wyp_get_select_markup(
						'justify-content',
						'Выровнять содержание',
						array(
							'normal' => 'normal',
							'flex-start' => 'start',
							'flex-end' => 'end',
							'center' => 'center',
							'space-between' => 'space-between',
							'space-around' => 'space-around',
						),
						"",
						'Выравнивает элементы гибкого контейнера, когда элементы не используют все доступное пространство на главной оси (по горизонтали).).'
					)."

					".wyp_get_select_markup(
						'align-items',
						'Выровнять элементы',
						array(
							'normal' => 'normal',
							'stretch' => 'stretch',
							'center' => 'center',
							'flex-start' => 'start',
							'flex-end' => 'end',
							'baseline' => 'baseline',
						),
						"",
						'Задает выравнивание по умолчанию для элементов внутри гибкого контейнера..'
					)."
					</div>

					".wyp_get_select_markup(
						'align-content',
						'Выровнять содержимое',
						array(
							'normal' => 'normal',
							'stretch' => 'stretch',
							'center' => 'center',
							'flex-start' => 'start',
							'flex-end' => 'end',
							'space-between' => 'space-between',
							'space-around' => 'space-around',
						),
						"",
						'Задает выравнивание по умолчанию для элементов внутри гибкого контейнера..'
					)."

					".wyp_get_radio_markup(
						'flex-wrap',
						'Children',
						array(
							'nowrap' => 'no wrap',
							'wrap' => 'wrap',
						),
						'',
						'Указывает, должны ли гибкие элементы переноситься или нет..'
					)."
					</div>

					<div class='flex-child-section'>
					".wyp_get_radio_markup(
						'flex',
						'Размеры',
						array(
							'0 1 auto' => 'Сокращаться, сжиматься',
							'1 1 0%' => 'Расти',
							'0 0 auto' => 'Нет роста и сокращения'
						),
						"",
						'Устанавливает гибкую длину для гибких элементов.'
					)."

					".wyp_get_select_markup(
						'align-self',
						'Выровнять',
						array(
							'auto' => 'auto',
							'stretch' => 'stretch',
							'center' => 'center',
							'flex-start' => 'start',
							'flex-end' => 'end',
							'baseline' => 'baseline',
						),
						"",
						'Указывает выравнивание для выбранного элемента внутри гибкого контейнера..'
					)."

				</div>

				<div class='grid-section'>

					".wyp_grid_builder(
						'grid-template-columns',
						'Столбцы',
						'Определяет количество (и ширину) столбцов в макете сетки.'
					)."

					".wyp_grid_builder(
						'grid-template-rows',
						'Ряды',
						'Указывает количество (и высоту) строк в макете сетки.'
					)."

					<div class='option-group-class'>
					".wyp_get_select_markup(
						'align-content',
						'Выровнять',
						array(
							'normal' => 'normal',
							'stretch' => 'stretch',
							'center' => 'center',
							'flex-start' => 'start',
							'flex-end' => 'end',
							'space-between' => 'space-between',
							'space-around' => 'space-around',
						),
						"",
						'Изменяет поведение свойства flex-wrap. Он похож на align-items, но вместо выравнивания flex-элементов он выравнивает flex-линии..'
					)."

					".wyp_get_select_markup(
						'justify-content1',
						'Justify',
						array(
							'normal' => 'normal',
							'flex-start' => 'start',
							'flex-end' => 'end',
							'center' => 'center',
							'space-between' => 'space-between',
							'space-around' => 'space-around',
						),
						"",
						'Выравнивает элементы гибкого контейнера, когда элементы не используют все доступное пространство на главной оси (по горизонтали).).'
					)."
					</div>

					".wyp_get_slider_markup(
						'column-gap',
						'Разрыв столбца',
						'normal',
						1,        // steps
						'0,100',   // px value
						'0,100',  // percentage value
						'0,100',     // Em value
						'Определяет размер промежутка между столбцами в макете сетки.'
					)."

					".wyp_get_slider_markup(
						'row-gap',
						'Разрыв строки',
						'normal',
						1,        // steps
						'0,100',   // px value
						'0,100',  // percentage value
						'0,100',     // Em value
						'Определяет размер промежутка между строками в макете сетки..'
					)."

				</div>

				<div class='option-group-class'>
				".wyp_get_radio_markup(
					'float',
					'Float',
					array(
						'none' => 'none',
						'left' => 'left',
						'right' => 'right'
					),
					"",
					'Указывает, как элемент должен плавать.'
				)."

				".wyp_get_radio_markup(
					'clear',
					'Clear',
					array(
						'none' => 'none',
						'both' => 'both'
					),
					"",
					'Указывает, какие элементы могут плавать рядом с очищенным элементом и с какой стороны.'
				)."
				</div>

				".wyp_get_radio_markup(
					'visibility',
					'Видимость',
					array(
						'visible' => '<span class="yicon icon-visibility"></span>',
						'hidden' => '<span class="yicon icon-hidden"></span>'
					),
					"",
					'Указывает, виден ли элемент.'
				)."

				".wyp_get_slider_markup(
					'opacity',
					'Непрозрачность',
					'',
					0.01,       // steps
					'0,1',   // px value
					'0,1',  // percentage value
					'0,1',     // Em value
					'Устанавливает уровень непрозрачности для элемента.'
				)."

				<div class='option-group-class'>
				".wyp_get_select_markup(
					'cursor',
					'Курсор',
					array(
						'auto' => 'auto',
						'alias' => 'alias',
						'all-scroll' => 'All Scroll',
						'copy' => 'Copy',
						'crosshair' => 'CrossHair',
						'grab' => 'Grab',
						'grabbing' => 'Grabbing',
						'help' => 'Help',
						'not-allowed' => 'Not Allowed',
						'pointer' => 'Pointer',
						'progress' => 'Progress',
						'text' => 'Text',
						'wait' => 'Wait',
						'zoom-in' => 'Zoom In',
						'zoom-out' => 'Zoom Out'
					),
					"",
					'Определяет тип курсора, который будет отображаться при указании на элемент.'
				)."

				".wyp_get_radio_markup(
					'pointer-events',
					'События указателя',
					array(
						'auto' => 'auto',
						'none' => 'none'
					),
					"",
					'Указывает, при каких обстоятельствах (если таковые имеются) конкретный графический элемент может стать целью событий мыши..'
				)."
				</div>

			</div>

		</li>

	</ul></form>";
